<form action="index.php?module=etudiant&action=creerGroupe" method="POST" />
	<!-- Material input -->
	<div class="md-form">
	  <input type="text" id="form1" class="form-control" name="nomGroupe" required>
	  <label for="form1">Nom du groupe</label>
	</div>
	<input type="submit" value="créer" />
</form>