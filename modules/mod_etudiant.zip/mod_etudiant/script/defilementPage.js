
	function changeImgG(){
		document.getElementById('flecheG').src="ressources/imgSite/logos/gestion/prec2.png";
	}

	function changeImgD(){
		document.getElementById('flecheD').src="ressources/imgSite/logos/gestion/suivant2.png";
	}

	function defaultImgG(){
		document.getElementById('flecheG').src="ressources/imgSite/logos/gestion/prec.png";
	}

	function defaultImgD(){
		document.getElementById('flecheD').src="ressources/imgSite/logos/gestion/suivant.png";
	}
