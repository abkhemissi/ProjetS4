$(document).ready(function(){
    
    $('#contenuAdresse2').slideDown(700);
  
    $('#contenuSituationActuelle').slideDown(700);
});